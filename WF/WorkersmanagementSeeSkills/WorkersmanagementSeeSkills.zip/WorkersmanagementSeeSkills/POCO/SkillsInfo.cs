﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace WorkersmanagementSeeSkills.POCO
{
    [Table("SkillsInfo")]
    public partial class SkillsInfo
    {
        [Key]
        public int SkillInfoID { get; set; }

        [Required]
        [StringLength(250)]
        public string URL { get; set; }

        public int SkilID { get; set; }

        public virtual Skills Skills { get; set; }
    }
}
