﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WorkersmanagementSeeSkills.POCO;

namespace WorkersmanagementSeeSkills.DAL
{
   
        // like singlton
   public class DataAccesslayer
   {

       #region Datamember

       private static string con = ConfigurationManager.ConnectionStrings["emp"].ConnectionString;
       private static SqlConnection sqlCon  = new SqlConnection(con);
       private static DataAccesslayer dal;

      #endregion
       #region like singlton

       public static DataAccesslayer Datamanger()
       {
           if (dal==null)
           {
               return dal = new DataAccesslayer();
           }
           else
           {
               return dal;
           }
       }
       #endregion
       #region Open
       public static void Open()
       {
           try
           {
         
               sqlCon.Open();

           }
           catch (Exception e)
           {
               MessageBox.Show(e.Message);

           }


       }
      
	#endregion
       #region Close
       public static void Close()
       {
           try
           {

               
               sqlCon.Close();

           }
           catch (Exception)
           {
               MessageBox.Show("Failed to connect to data source");

           }

       }
       #endregion
       #region Employ
        public static DataTable SelectEmploy()
        {
           string query = String.Format("SELECT EmployeeID, LastName, FirsName, Alias, Email FROM  Employees ");
            SqlCommand com = new SqlCommand();
            com.CommandText = query;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);

            com.Dispose();


            return da;

           
        }
        #endregion
       #region SelectSkillsEmp where id employees

        public static DataTable SelectSkillsEmpwhereID(int  employID)
        {
            string qery = string.Format("SELECT  SkilID, EmployeeID, SkillName, BrifDescription FROM Skills where EmployeeID= @EmployeeID");
            SqlCommand com = new SqlCommand();
            SqlParameter parm = new SqlParameter();
            parm.ParameterName = "@EmployeeID";
            parm.SqlDbType = SqlDbType.Int;
            parm.Value = employID;
            com.Parameters.Add(parm);
            com.CommandText = qery;
            com.Connection = sqlCon;
            DataTable da = new DataTable();
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);        
            com.Dispose();
            return da;
           

        }
        #endregion
       #region SelectSkillsEmp

        public static DataTable SelectSkillsEmp()
        {
            string qery = string.Format("SELECT  SkilID, EmployeeID, SkillName, BrifDescription FROM Skills");
            SqlCommand com = new SqlCommand();
            com.CommandText = qery;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;

          

        }
        #endregion
       #region Select Search of employees

        public static DataTable SelectOfSearchOfEmployee(string search)
        {
            string query = String.Format("SELECT Employees.EmployeeID,Employees.LastName, Employees.FirsName, Employees.Alias, Employees.Email FROM Employees INNER JOIN Skills ON Employees.EmployeeID = Skills.EmployeeID WHERE (SkillName = @skillname)");

            SqlParameter par = new SqlParameter();
            SqlCommand com = new SqlCommand();

            par.ParameterName = "@skillname";
            par.SqlDbType = SqlDbType.NVarChar;
            par.Value = search;
            par.Size = 250;
            com.Parameters.Add(par);
            com.CommandText = query;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;
            
        }

        #endregion
       #region InsertRef

        public static void InsertRef(string lastName, string firstName, string position, string alias, string email, int empID)
        {
            string qery = string.Format("INSERT INTO Ref(LastName,FirstName, Position, Alias, Email, EmloyeeID)VALUES (@LastName,@FirstName,@Position,@Alias,@Email,@EmloyeeID)");
            SqlCommand com = new SqlCommand();

            SqlParameter par = new SqlParameter();
            par.ParameterName = "@LastName";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = lastName;
            com.Parameters.Add(par);

            par = new SqlParameter();
            par.ParameterName = "@FirstName";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = firstName;
            com.Parameters.Add(par);


            par = new SqlParameter();
            par.ParameterName = "@Position";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = position;
            com.Parameters.Add(par);

            par = new SqlParameter();
            par.ParameterName = "@Alias";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = alias;
            com.Parameters.Add(par);

            par = new SqlParameter();
            par.ParameterName = "@Email";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = email;
            com.Parameters.Add(par);

            par = new SqlParameter();
            par.ParameterName = "@EmloyeeID";
            par.SqlDbType = SqlDbType.Int;
            par.Value = empID;
            com.Parameters.Add(par);
            com.CommandText = qery;
            com.Connection = sqlCon;
            com.ExecuteNonQuery();
            com.Dispose();







        }
        #endregion
       #region InsertEmployees

        public static void InsertEmployees(string firstName, string lastName, string alias, string email)
        {
            string qery = string.Format("INSERT INTO Employees(LastName, FirsName, Alias, Email)VALUES (@LastName,@FirsName,@Alias,@Email) ");
            SqlCommand com = new SqlCommand();

            SqlParameter par = new SqlParameter();
            par.ParameterName = "@LastName";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = lastName;
            com.Parameters.Add(par);
            par = new SqlParameter();
            par.ParameterName = "@FirsName";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = firstName;
            com.Parameters.Add(par);
            par = new SqlParameter();
            par.ParameterName = "@Alias";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = alias;
            com.Parameters.Add(par);
            par = new SqlParameter();
            par.ParameterName = "@Email";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = email;
            com.Parameters.Add(par);
            com.CommandText = qery;
            com.Connection = sqlCon;
            com.ExecuteNonQuery();
            com.Dispose();





        }
        #endregion
       #region SelectSkillsEmp where id skill

        public DataTable SelectSkillsEmpwhereIDskill(Skills skill)
        {
            string qery = string.Format("SELECT  SkilID, EmployeeID, SkillName, BrifDescription FROM Skills where (SkilID =@SkilID)");
            SqlCommand com = new SqlCommand();
            SqlParameter parm = new SqlParameter();
            parm.ParameterName = "@SkilID";
            parm.SqlDbType = SqlDbType.Int;
            parm.Value = skill.SkilID;
            com.Parameters.Add(parm);
            com.CommandText = qery;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;
            

        }
        #endregion
       #region SelectURL
        public static DataTable SelectskillURL(int SkillsInfoid)
        {
            string qery = string.Format("SELECT  URL FROM SkillsInfo WHERE (SkilID =@SkilID)");
            SqlCommand com = new SqlCommand();
            SqlParameter par = new SqlParameter();
            par.Value = SkillsInfoid;
            par.ParameterName = "@SkilID";
            par.SqlDbType = SqlDbType.Int;
            com.Parameters.Add(par);
            com.CommandText = qery;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;

        }
        #endregion
       #region Select referenc
        public DataTable SelectRef(Ref employID)
        {
            string qery = string.Format("SELECT  * FROM Reference where EmloyeeID=@EmloyeeID");
            SqlCommand com = new SqlCommand();
            SqlParameter parm = new SqlParameter();
            parm.ParameterName = "@EmloyeeID";
            parm.SqlDbType = SqlDbType.Int;


            parm.Value = employID.EmloyeeID;
            com.Parameters.Add(parm);
            com.CommandText = qery;
            DataTable da = new DataTable();
            com.Connection = sqlCon;
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;

        }
        #endregion
       #region InsertURL

        public  static void InsertURL(string skiInfo, int SkilID )
        {
            string qery = string.Format("INSERT INTO SkillsInfo(URL, SkilID)VALUES (@URL,@SkilID)");
            SqlCommand com = new SqlCommand();

            SqlParameter par = new SqlParameter();
            par.ParameterName = "@URL";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 250;
            par.Value = skiInfo;
            com.Parameters.Add(par);
            par = new SqlParameter();

            par.ParameterName = "@SkilID";
            par.SqlDbType = SqlDbType.Int;

            par.Value = SkilID;
            com.Parameters.Add(par);
            com.CommandText = qery;
            com.Connection = sqlCon;
            com.ExecuteNonQuery();
            com.Dispose();




        }
        #endregion
       #region Inserskill

        public static void InsertSkill(int empid ,string skillName,string brifDescription  )
        {
            string qery = string.Format("INSERT INTO Skills(EmployeeID,SkillName, BrifDescription)VALUES (@EmployeeID,@SkillName,@BrifDescription)");
            SqlCommand com = new SqlCommand();
            SqlParameter par = new SqlParameter();





            par.ParameterName = "@EmployeeID";
            par.SqlDbType = SqlDbType.Int;
            par.Value = empid;
            com.Parameters.Add(par);
            par = new SqlParameter();
            par.ParameterName = "@SkillName";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = skillName;
            com.Parameters.Add(par);
            par = new SqlParameter();
            par.ParameterName = "@BrifDescription";
            par.SqlDbType = SqlDbType.NChar;
            par.Size = 50;
            par.Value = brifDescription;
            com.Parameters.Add(par);
            com.CommandText = qery;
            com.Connection = sqlCon;
            com.ExecuteNonQuery();
            com.Dispose();
            




        }
        #endregion
        #region Select referenc
        public static DataTable SelectRef(int employID)
        {
            string qery = string.Format("SELECT LastName,FirstName,Position ,Alias,Email  FROM Ref where EmloyeeID=@EmloyeeID");
            SqlCommand com = new SqlCommand();
            SqlParameter parm = new SqlParameter();
            parm.ParameterName = "@EmloyeeID";
            parm.SqlDbType = SqlDbType.Int;


            parm.Value = employID;
            com.Parameters.Add(parm);
            com.CommandText = qery;
            com.Connection = sqlCon;
            DataTable da = new DataTable();
            SqlDataReader re = com.ExecuteReader();
            da.Load(re);
            com.Dispose();
            return da;
            
           


        }
        #endregion



    }
}



  
