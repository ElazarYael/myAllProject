﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace WorkersmanagementSeeSkills.POCO
{
    public partial class Skills
    {
       

        [Key]
        public int SkilID { get; set; }

        public int EmployeeID { get; set; }

        [Required]
        [StringLength(50)]
        public string SkillName { get; set; }

        [Required]
        [StringLength(100)]
        public string BrifDescription { get; set; }

        public virtual Employees Employees { get; set; }

        public virtual ICollection<SkillsInfo> SkillsInfo { get; set; }
    }
}
