﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace WorkersmanagementSeeSkills.POCO
{

    [Table("Ref")]
    public partial class Ref
    {
        [Key]
        public int ReferenceID { get; set; }
        public int EmloyeeID { get; set; }
        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        [StringLength(50)]
        public string FirstName { get; set; }

        [StringLength(50)]
        public string Position { get; set; }

        [Required]
        [StringLength(50)]
        public string Alias { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

      

        public virtual Employees Employees { get; set; }
    }
}
