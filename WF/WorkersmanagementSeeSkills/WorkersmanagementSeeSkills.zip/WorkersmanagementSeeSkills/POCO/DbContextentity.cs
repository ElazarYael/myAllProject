﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkersmanagementSeeSkills.POCO
{
    
    public partial class DbContextentity : DbContext
    {
        public DbContextentity()
            : base("emp")
           
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<DbContextentity>());
        }

        public virtual DbSet<Employees> Employees { get; set; }
        public virtual DbSet<Ref> Reference { get; set; }
        public virtual DbSet<Skills> Skills { get; set; }
        public virtual DbSet<SkillsInfo> SkillsInfo { get; set; }


    }
}
