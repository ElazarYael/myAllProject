﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WorkersmanagementSeeSkills.POCO;
namespace WorkersmanagementSeeSkills.BiznizLogincs
{
    class BiznizLogincs
    {
       
        public BiznizLogincs()
        {
            DAL.DataAccesslayer.Open();
        }
        #region SelectEMP
        
        public DataTable Selectemp() 
        {
            return DAL.DataAccesslayer.SelectEmploy();
        
        }
        #endregion
        #region Select skill
        
     
        public DataTable Selectskill()
        {
            return DAL.DataAccesslayer.SelectSkillsEmp();
        }
         #endregion
        #region select skill where empID
        
      
        public DataTable SeleIDemp(int idemp)  
        {
            return DAL.DataAccesslayer.SelectSkillsEmpwhereID(idemp);
        }
        #endregion
        #region SelecURL
        
      
        public bool SelURL( int idskill,out string urlsrt)
        {
            DataTable dat = new DataTable();
            dat = DAL.DataAccesslayer.SelectskillURL(idskill);
          
         
            if (dat.Rows.Count.Equals(0))
	        {
                urlsrt = "";
                return true;
		 
	        }
            urlsrt = urlsrt = dat.Rows[0][0].ToString();;
            return false; 
        
        }
        #endregion
        #region SeleSearch
       
        public DataTable SelectOfSearchOf(string txt)
        {
           int n;
            bool isNumeric = int.TryParse(txt, out n);
            if (isNumeric)
	            {
                   MessageBox.Show("no number pleas put name skill".ToLowerInvariant());
	            }
            else
            {
                if (DAL.DataAccesslayer.SelectOfSearchOfEmployee(txt).Rows.Count.Equals(0))
                {
                    MessageBox.Show("0 items found");
                }
             
            }
                return DAL.DataAccesslayer.SelectOfSearchOfEmployee(txt); 
      
        }
         #endregion
        #region InserEmployee
        
       
        public bool InsertEmp(string firstName, string lastName, string alias, string email) 
        {

            bool isnull= IsnullOrEmpty(alias)||(IsnullOrEmpty(lastName)||(!email.ToLower().Contains("@")));
            if (isnull)
            {
                return false;
            }
            DAL.DataAccesslayer.InsertEmployees(firstName, lastName, alias, email);
            return true;
          
           
        
        }
        #endregion
        #region InserUrl
        
        
        public bool InserUrl(string texUrl, int idskill)
        {
            
            bool https = IsnullOrEmpty(texUrl);
          
         
            if (https)
            {
               
                return false;

            }
            else if (texUrl.ToLower().Contains("https"))
            {
               
                string url;
                if (SelURL(idskill,out url))
	                {
                        DAL.DataAccesslayer.InsertURL(texUrl, idskill);
                  
                        return true;
		 
	                }
               
            }
            return false;
           
               
     
       
        }
        #endregion
        #region InsertSkill
        
       

        public bool InsertSkill(int empID, string nameskill,string brief)
        {
            bool inserSkil=(IsnullOrEmpty(nameskill)||(IsnullOrEmpty(brief)));
            if (!(inserSkil))
	        {
                 DAL.DataAccesslayer.InsertSkill(empID,nameskill, brief);
		        return true; 
	        }
            return false;


           
        }
         #endregion
        #region IsnullOrEmpty
        
       
        public bool IsnullOrEmpty(string parm)
        {
            if ((parm.Equals(null))||(parm.Equals(""))||(parm.All(Char.IsNumber)))
	            {
                    return true;
	            }
            else
                {
                    return false;
                }

        }
        #endregion
        #region IsNum
        
       
        public bool IsNum(string parm)
        {
            if (parm.All(Char.IsNumber))
            {
                return true;
            }
            else
            {
                return false;
            }



       }

        #endregion
        #region SelRef
        public string SelRrf(int empId) 
        {
            DataTable db = new DataTable();
            string refIdEmp = "";

         db=  DAL.DataAccesslayer.SelectRef(empId);

        for (int i = 0; i < db.Rows.Count; i++)
			{
                refIdEmp +=string.Join("", db.Rows[i].ItemArray.GetValue(i).ToString().Trim());
			}
        
            return refIdEmp;
        
        }
        #endregion
        #region InserRef

        public bool InserRef(string lastName,string firstName,string position,string alias,string email,int empID) 
        {

            if (IsnullOrEmpty(alias)|| IsnullOrEmpty(lastName)||(!(email.ToLower().Contains("@"))))
            {

                return false;
            }
            else
            {
                DAL.DataAccesslayer.InsertRef(lastName, firstName, position, alias, email, empID);
                return true;
            }
          
        }
          
        #endregion
        #region Close
        
       
        public void Close() 
        {
            DAL.DataAccesslayer.Close();

        }
        #endregion
    }
}
